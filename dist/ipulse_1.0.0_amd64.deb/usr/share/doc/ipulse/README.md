# iPulse

**Internet connection monitoring, network observability and anomaly detection — running
as a real service on Windows and Linux, storing everything locally.**

iPulse answers the question you actually have when the Internet feels wrong: *what is
broken, and is it me or them?* It measures availability, latency, jitter, loss and speed
continuously, watches what your machine is talking to, and when something breaks it runs
a layered diagnosis and tells you which layer failed — with the evidence attached.

```text
$ ipulse status

iPulse Internet Monitor

Service:            Running
Internet:           Online
Health Score:       94/100
Download:           487.2 Mbps
Upload:             41.8 Mbps
Latency:            18.6 ms
Jitter:             2.9 ms
Packet Loss:        0.0%
DNS:                12.4 ms
Public IP:          203.0.113.41
ISP:                AS64496 Example Networks
Interface:          eth0
Last Speed Test:    2 minutes ago
Availability (24h): 99.986% (1 outage)
```

## Screenshots

<!-- Replace these placeholders with real captures from your own installation. -->

| View | Screenshot |
|---|---|
| Overview — status, health score, live quality, recent events | `docs/images/overview.png` |
| Speed — download/upload over time against your ISP plan | `docs/images/speed.png` |
| Latency — RTT, jitter, packet loss and DNS | `docs/images/latency.png` |
| Availability — outages with duration and probable cause | `docs/images/availability.png` |
| Connections — searchable process/destination table | `docs/images/connections.png` |
| Events — syslog-style viewer with filters | `docs/images/events.png` |

The dashboard is at `http://127.0.0.1:8750` and is bound to loopback by default.

## What it does

**Connection quality, continuously.** Health checks every 15 seconds, DNS and latency
every 30, a lightweight throughput probe every 5 minutes, a full speed test every 30.
Every interval is configurable, and iPulse never runs bandwidth-saturating tests on a
loop.

**Speed testing that means something.** Multi-stream download and upload with a discarded
warm-up, bounded by both time and a byte cap so a fast link cannot burn a metered
allowance. Results are compared against your advertised ISP plan and against
time-of-day-aware historical baselines, with mean, median, min, max, percentiles and
standard deviation over the hour, day, week and month.

**Outage diagnosis, not just outage detection.** When connectivity fails, iPulse tests
each layer independently and reports the lowest broken one:

```text
local device → network interface → default gateway → DNS → ISP → Internet
```

The result is a classification (`ISP_OUTAGE`, `DNS_FAILURE`, `GATEWAY_FAILURE`,
`LOCAL_INTERFACE_FAILURE`, `PARTIAL_CONNECTIVITY`, `WIFI_DEGRADATION`, …) with the
evidence that produced it, stored alongside the outage's start, end and duration.

**Traffic and connection observability.** Interface throughput with counter-reset
handling, active TCP and UDP connections attributed to the processes that own them,
destination history with reverse DNS and optional ASN enrichment, and detection of new,
rare, high-volume and unexpectedly-ported destinations.

**Anomaly detection you can audit.** Time-aware adaptive baselines (a Tuesday afternoon
is compared with other weekday afternoons, not with 3 AM on Sunday), deterministic
deviation rules with persistence and hysteresis, and an event-correlation engine that
replaces a list of symptoms with one conclusion:

```text
2026-08-24T14:47:22-05:00 WARN IPULSE-2107 LOCAL_BANDWIDTH_SATURATION
Direction=upload
CurrentLatency=73.0ms
PacketLoss=2.1%
PeakUpload=94.2Mbps
TopProcess=backup-agent
ProbableCause="LOCAL BANDWIDTH SATURATION"
Evidence="BANDWIDTH_SPIKE_UPLOAD(CurrentRate=94.0Mbps) + LATENCY_DEGRADATION(Deviation=305%) + PACKET_LOSS_DETECTED(PacketLoss=2.1%)"
```

**Security signals, stated carefully.** Threat-intelligence matching against indicators
you import (no vendor assumed, no feed shipped), and lateral-movement heuristics for host
sweeps, port scans and remote-administration probing. Every finding carries a confidence
and says what it does *not* mean. iPulse never blocks traffic and never claims a match is
confirmed malicious activity.

## Architecture

```text
                       ┌─────────────────────────────────────────────┐
  systemd / SCM  ────▶  │  Service Manager  →  Agent  →  Scheduler    │
                       │                          │                  │
                       │        ┌─────────────────┴─────────────┐     │
                       │        │  connectivity · latency · DNS │     │
                       │        │  interfaces · Wi-Fi · traffic │     │
                       │        │  connections · destinations   │     │
                       │        │  speed test · public IP · route│    │
                       │        │  threat intel · lateral       │     │
                       │        └─────────────────┬─────────────┘     │
                       │                          │                  │
                       │   Bus → Baselines → Anomaly → Correlation    │
                       │                          │                  │
                       │              Events → Logging Engine         │
                       │                          │                  │
                       │        SQLite  ·  .log  ·  .jsonl  ·  OS log │
                       │                          │                  │
                       │                REST API + Dashboard          │
                       └─────────────────────────────────────────────┘
                                            ▲
   ipulse status / events / connections ────┘  (HTTP on 127.0.0.1:8750)
```

Every OS-specific mechanism lives behind `internal/platform`: Linux reads `/proc`,
`/sys`, netlink (nl80211) and the socket error queue; Windows calls `iphlpapi`, `wlanapi`
and the process/token APIs. Nothing else in the tree knows which platform it is on.
See [docs/architecture.md](docs/architecture.md).

## Installation

### Linux (Debian, Ubuntu)

```bash
sudo dpkg -i ipulse_1.0.0_amd64.deb
sudo systemctl status ipulse
```

### Linux (Fedora, RHEL, openSUSE)

```bash
sudo rpm -i ipulse-1.0.0-1.x86_64.rpm
sudo systemctl status ipulse
```

### Linux (any distribution, from a binary)

```bash
sudo scripts/install.sh
```

### Windows 10/11 and Server 2019+

```powershell
msiexec /i ipulse-1.0.0-x64.msi        # or: .\packaging\windows\install.ps1
Get-Service iPulse
```

### Portable / developer mode

No installation, no service, nothing outside one directory:

```bash
ipulse run --portable ./ipulse-home
```

Full details: [Linux](docs/installation-linux.md) · [Windows](docs/installation-windows.md)

## Basic commands

```bash
ipulse status                  # current state at a glance
ipulse test                    # connectivity, DNS and latency, now
ipulse test speed              # a full speed test, now
ipulse test route              # measure the path to a destination
ipulse diagnostics             # run the layered diagnostic ladder
ipulse diagnostics --privileges  # what iPulse can and cannot do here, and why

ipulse events --severity warning --since 24h
ipulse events --category security --since 7d
ipulse events -f                       # follow, like tail -f
ipulse events catalog --code 3004      # explain an event ID

ipulse connections --top               # per-process activity
ipulse destinations --new 24h          # destinations first seen today
ipulse destinations --flagged          # threat-intelligence matches

ipulse config                          # effective configuration
ipulse config validate                 # check a file before applying it
ipulse start | stop | restart          # service control
ipulse version
```

Every command takes `--json` for scripting.

## Configuration

`/etc/ipulse/ipulse.yaml` on Linux, `C:\ProgramData\iPulse\config\ipulse.yaml` on
Windows. The one setting worth changing immediately is your ISP plan, which is what
turns "487 Mbps" into "97 % of what you pay for":

```yaml
speed_test:
  expected_download_mbps: 500
  expected_upload_mbps: 50
```

Unknown keys are rejected rather than ignored, and `ipulse config validate` reports every
problem at once. See [docs/configuration.md](docs/configuration.md) for every option.

## Building from source

Requires Go 1.24 or later. There are no cgo dependencies, so a single command produces a
static binary for any supported platform.

```bash
git clone https://github.com/ipulse/ipulse
cd ipulse

make build          # host platform, into bin/
make build-all      # every platform, into dist/
make test           # vet, format check, cross-compile check, full test suite
make deb rpm        # packages, into dist/
make help           # every target
```

## Testing

```bash
make test           # everything
make test-short     # skip the tests that use the network
make race           # with the race detector
make cover          # with a coverage summary
```

The suite runs offline. Outages, packet loss, saturation, scans and threat matches are
all simulated through the detection pipeline rather than requiring a real fault:

```bash
go test ./internal/agent/ -run TestSimulate -v
```

See [docs/development.md](docs/development.md).

## Privacy

iPulse collects **metadata only**. It records that a process connected to an address on a
port, how long it lasted, and what the connection quality was. It does not capture packet
payloads, HTTP bodies, TLS plaintext, documents or keystrokes, and it performs no TLS
interception — `privacy.payload_inspection` exists solely so that setting it to true is
*rejected* by configuration validation.

Nothing leaves the machine unless you ask it to. There is no cloud account, no telemetry,
no analytics and no phone-home. The only outbound traffic is the measurement traffic you
configure: probe targets, speed-test endpoints, public-IP providers, and any threat feeds
you add. Every identity field — process names, executable paths, usernames, reverse DNS —
has its own switch.

See [docs/privacy.md](docs/privacy.md).

## Security

The service does not run as root on Linux. It runs as a dedicated unprivileged account
with two capabilities — `CAP_NET_RAW` for ICMP and path measurement, and
`CAP_DAC_READ_SEARCH` for process attribution — under a hardened unit
(`ProtectSystem=strict`, `NoNewPrivileges`, `PrivateTmp`, a syscall filter and a
restricted address-family list). On Windows it runs as LocalSystem because the extended
socket tables and the WLAN API require it.

The API and dashboard are bound to loopback, protected by a Host allow-list that defeats
DNS rebinding, and refuse to bind anywhere else without an authentication token.
Configuration input is validated, log values are sanitised so a hostile process name
cannot forge a log record, and no part of iPulse invokes a shell.

`ipulse diagnostics --privileges` prints exactly what is available on your host and what
each missing privilege costs. See [docs/security.md](docs/security.md).

## Documentation

| Document | Contents |
|---|---|
| [architecture.md](docs/architecture.md) | Design, module map, platform boundary, data flow |
| [installation-linux.md](docs/installation-linux.md) | Packages, manual install, systemd, upgrades |
| [installation-windows.md](docs/installation-windows.md) | MSI, PowerShell, the service, upgrades |
| [configuration.md](docs/configuration.md) | Every option, with defaults and guidance |
| [event-catalog.md](docs/event-catalog.md) | Every event iPulse can emit (generated from the code) |
| [detection-engine.md](docs/detection-engine.md) | Baselines, thresholds and correlation rules, in full |
| [api.md](docs/api.md) | REST API reference |
| [security.md](docs/security.md) | Privilege matrix, hardening, threat model |
| [privacy.md](docs/privacy.md) | What is collected, what is not, and how to reduce it |
| [troubleshooting.md](docs/troubleshooting.md) | Symptoms, causes and fixes |
| [development.md](docs/development.md) | Building, testing, adding a collector or a provider |

## Design principles

1. Low resource use: one process, bounded queues, no busy loops.
2. Works offline apart from the probes that inherently need the Internet.
3. No mandatory cloud account or external service.
4. Local-first storage.
5. Human-readable logs.
6. Transparent detection: every rule is documented and deterministic.
7. Cross-platform by construction.
8. Extensible providers for speed testing, enrichment and threat intelligence.
9. No vendor lock-in.
10. Privacy by default.
11. Never describe an anomaly as confirmed malicious activity.

## Licence

MIT. See [LICENSE](LICENSE).
